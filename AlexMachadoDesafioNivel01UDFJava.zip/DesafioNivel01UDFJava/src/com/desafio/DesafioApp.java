package com.desafio;

import javax.swing.JOptionPane;

public class DesafioApp {
	
	// Nome do programador: Alex Machado

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// instanciando o funcionário
		Funcionario funcionario = new Funcionario();
		
		// entrada de dados
		funcionario.setNome(JOptionPane.showInputDialog("Informe o nome do funcionário:"));
		funcionario.setDataNascimento(JOptionPane.showInputDialog("Informe a data de nascimento:"));
		funcionario.setCep(JOptionPane.showInputDialog("Informe o CEP:"));
		funcionario.setUf(JOptionPane.showInputDialog("Informe a unidade da federação:"));
		funcionario.setMunicipio(JOptionPane.showInputDialog("Informe o Município:"));
		funcionario.setBairro(JOptionPane.showInputDialog("Informe o Bairro:"));
		funcionario.setLogradouro(JOptionPane.showInputDialog("Informe o logradouro:"));
		funcionario.setComplemento(JOptionPane.showInputDialog("Informe o complemento:"));
		funcionario.setNumeroEnd(JOptionPane.showInputDialog("Informe o número do endereço:"));
		funcionario.setCargo(JOptionPane.showInputDialog("Informe o cargo:"));
		funcionario.setSalario(Double.parseDouble(JOptionPane.showInputDialog("Informe o salário:").replace(",", ".")));
		
		// saída de dados
		JOptionPane.showMessageDialog(null, 
				"Dados do funcionário:\n\nNome: " + funcionario.getNome() + 
				".\nData de nascimento: " + funcionario.getDataNascimento() +
				".\nEndereço:\nCEP: " + funcionario.getCep() +
				".\nUF: " + funcionario.getUf() +
				".\nMunicípio: " + funcionario.getMunicipio() +
				".\nBairro: " + funcionario.getBairro() +
				".\nLogradouro: " + funcionario.getLogradouro() +
				".\nComplemento: " + funcionario.getComplemento() +
				".\nNúmero: " + funcionario.getNumeroEnd() +
				".\nCargo: " + funcionario.getCargo() +
				".\nSalário: R$ " + String.format("%.2f", funcionario.getSalario()) + "."
		);
		
	}

}
